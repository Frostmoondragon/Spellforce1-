# SpellForceLUASources
LUA Source files for SpellForce: The Order of Dawn, The Breath of Winter and Shadow of the Phoenix (SpellForce Platinum Edition)

Previously those lua files were only available in compiled format. Now the originals can be used to mod the game.

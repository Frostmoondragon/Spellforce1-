OnQuestItemFound
	{
	ItemId = 3624 , ItemFlagName = "Gift" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 3624 , ItemFlagName = "Gift" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 3625 , ItemFlagName = "Rune01" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 3805 , ItemFlagName = "WumpusTongue" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 4153 , ItemFlagName = "Schluesselbund" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 4153 , ItemFlagName = "Schluesselbund" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 2378 , ItemFlagName = "ZolowinStone" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 2378 , ItemFlagName = "ZolowinStone" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 2379 , ItemFlagName = "RenyaStone" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 2379 , ItemFlagName = "RenyaStone" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 2380 , ItemFlagName = "GruolunStone" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 2380 , ItemFlagName = "GruolunStone" , Amount = 1
	}
	
OnQuestItemFound
	{
	ItemId = 4152 , ItemFlagName = "Fetisch" , Amount = 1
	}
	
OnQuestItemRemove
	{
	ItemId = 4152 , ItemFlagName = "Fetisch" , Amount = 1
	}
-- P102 ... Hero-Rune 01 Effekte


Lagerfeuer
{
 KitharLagerSW = { X = 124, Y = 199, When = NightOnly },
 KitharLagerS = { X = 262, Y = 164, When = NightOnly },
 KitharLagerO = { X = 410, Y = 178, When = NightOnly },
 KitharFestung01 = { X = 172, Y = 309, When = Always },
 KitharFestung02 = { X = 159, Y = 336, When = Always },
 KitharFestung03 = { X = 196, Y = 319, When = Always },
 JaninaGefangen = { X = 71, Y = 122, When = Always },
 }

Fackelfeuer
{	
FackelSetriusLager01 = { X = 276, Y = 389, When = NightOnly },
FackelSetriusLager02 = { X = 281, Y = 391, When = NightOnly },
FackelSetriusLager03 = { X = 280, Y = 384, When = NightOnly },

-- FackelFestung01 = { X = 84, Y = 44, When = NightOnly },
-- FackelFestung02 = { X = 87, Y = 44, When = Always },
-- FackelFestung03 = { X = 90, Y = 44, When = NightOnly },
-- Fackel4 = { X = 93, Y = 44, When = Always },
}




function CreateStateMachine(_Type,_PlatformId,_NpcId,_X,_Y)
BeginDefinition(_Type,_PlatformId,_NpcId,_X,_Y)

-- DO NOT ADD ANYTHING TO THIS SCRIPT !!!!!!!!!!!!!

-- so only addon1 patch events will be active...
LOAD_ONLY_ADDON1_PATCHES = 1


EndDefinition()
end

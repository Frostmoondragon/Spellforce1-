-- You Are Currently Editing: 
-----------------------------
--		GdsDefines2.lua
-----------------------------

-- globale variablen f�rs GDS system werden hier definiert!
-- define global constants

function DefineGlobalConstants2()
	gdkUi_csLife1	=	920353035
	gdkUi_csLife2	=	920353035
	gdkUi_csLife3	=	920353039
end

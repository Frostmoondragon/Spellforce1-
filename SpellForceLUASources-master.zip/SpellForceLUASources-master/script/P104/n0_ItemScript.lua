

	
OnQuestItemFound
{
	ItemId = 4227 , ItemFlagName = "Page119" , Amount = 1
}


	
OnQuestItemFound
{
	ItemId = 4228 , ItemFlagName = "Page120" , Amount = 1
}


	
OnQuestItemFound
{
	ItemId = 4229 , ItemFlagName = "Page121" , Amount = 1
}



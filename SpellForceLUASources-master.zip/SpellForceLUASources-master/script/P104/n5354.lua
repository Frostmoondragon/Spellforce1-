-- Anf�hrer einer Fl�chtlingstruppe ...
function CreateStateMachine(_Type,_PlatformId,_NpcId,_X,_Y)
BeginDefinition(_Type,_PlatformId,_NpcId,_X,_Y)

dofile("script/p104/n5354_Fluechtlings_Anfuehrer.lua")

EndDefinition()
end

return 
{
	Creo = 228,		-- creo elfen mp lvl 15
	[1] = { Amount = 2,		Unit = 552, },		-- warder ohne upgrade
	[2] = { Amount = 3,		Unit = 548, },		-- wintermage ohne upgrade
	[3] = { Amount = 5,		Unit = 551, },		-- wanderer ohne upgrade
}


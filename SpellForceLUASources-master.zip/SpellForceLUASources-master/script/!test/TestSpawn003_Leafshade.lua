return 
{
	Creo = 139,		-- creo menschen level 3
	[1] = { Amount = 6,		Unit = 543, },		-- rekruten
	[2] = { Amount = 4,		Unit = 544, },		-- scouts
	[3] = { Amount = 4,		Unit = 538, },		-- kleriker
}

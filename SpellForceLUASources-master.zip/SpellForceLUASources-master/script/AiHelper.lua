Idle = 1
Nomadic = 3
Agressive = 4
Defensive = 5
Script = 6
None = 9

Player = 28
Player2 = 29
Player3 = 30
Player4 = 31

Random = 0
RandomSeed = 34750


function Minutes(param)
	return (param *60)
end

function Hours(param)
	return (param *60*60)
end

	
OnQuestItemFound
{
	ItemId = 3746 , ItemFlagName = "Rune02" , Amount = 1
}

OnQuestItemFound
{
	ItemId = 3807, ItemFlagName = "Froschitem", Amount = 1
}

OnQuestItemRemove
{
	ItemId = 3807, ItemFlagName = "Froschitem", Amount = 1
}


OnQuestItemFound
{
	ItemId = 4257, ItemFlagName = "FirstFragment", Amount = 1
}

OnQuestItemRemove
{
	ItemId = 4257, ItemFlagName = "FirstFragment", Amount = 1
}



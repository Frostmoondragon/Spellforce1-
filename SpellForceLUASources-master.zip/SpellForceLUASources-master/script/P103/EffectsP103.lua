-- P103 ... Hero-Rune 02 Effekte


Lagerfeuer
{
 Lagerfeuer01 = { X = 90, Y = 375, When = NightOnly },
}

Fackelfeuer
{	
Fackel01 = { X = 51, Y = 345, When = NightOnly },
Fackel02 = { X = 61, Y = 345, When = NightOnly },
Fackel03 = { X = 74, Y = 370, When = NightOnly },
Fackel04 = { X = 76, Y = 381, When = NightOnly },
Fackel05 = { X = 97, Y = 365, When = NightOnly },
Fackel06 = { X = 82, Y = 413, When = NightOnly },
Fackel07 = { X = 93, Y = 416, When = NightOnly },
Fackel08 = { X = 354, Y = 318, When = NightOnly },
Fackel09 = { X = 367, Y = 311, When = NightOnly },
Fackel10 = { X = 376, Y = 344, When = NightOnly },
Fackel11 = { X = 382, Y = 350, When = NightOnly },
Fackel12 = { X = 389, Y = 350, When = NightOnly },
Fackel13 = { X = 383, Y = 333, When = NightOnly },
Fackel14 = { X = 414, Y = 341, When = Always },
Fackel15 = { X = 415, Y = 339, When = Always },
Fackel16 = { X = 414, Y = 337, When = Always },
Fackel17 = { X = 397, Y = 382, When = NightOnly },
Fackel18 = { X = 390, Y = 389, When = NightOnly },
Fackel19 = { X = 209, Y = 403, When = NightOnly },
Fackel20 = { X = 221, Y = 403, When = NightOnly },
Fackel21 = { X = 269, Y = 345, When = NightOnly },
Fackel22 = { X = 278, Y = 336, When = NightOnly },
Fackel23 = { X = 321, Y = 218, When = NightOnly },
Fackel24 = { X = 329, Y = 214, When = NightOnly },
Fackel25 = { X = 323, Y = 241, When = NightOnly },
Fackel26 = { X = 329, Y = 247, When = NightOnly },
Fackel29 = { X = 195, Y = 338, When = NightOnly },
Fackel30 = { X = 202, Y = 338, When = NightOnly },
Fackel31 = { X = 376, Y = 338, When = NightOnly },
Fackel32 = { X = 393, Y = 343, When = NightOnly },
Fackel33 = { X = 393, Y = 335, When = NightOnly },
}





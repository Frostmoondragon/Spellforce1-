function CreateStateMachine(_Type,_PlatformId,_NpcId,_X,_Y)
BeginDefinition(_Type,_PlatformId,_NpcId,_X,_Y)

-- DO NOT ADD ANYTHING TO THIS SCRIPT !!!!!!!!!!!!!

EndDefinition()
end

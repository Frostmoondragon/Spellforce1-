
Fackelfeuer
{
	fackel1 = { X = 273, Y = 565 },
	fackel2 = { X = 270, Y = 562 },
	fackel3 = { X = 281, Y = 559 },
	fackel4 = { X = 277, Y = 555 },
	fackel5 = { X = 288, Y = 552 },
	fackel6 = { X = 284, Y = 548 },
	fackel7 = { X = 296, Y = 544 },
	fackel8 = { X = 292, Y = 540 },
	fackel9 = { X = 304, Y = 536 },
	fackel10 = { X = 300, Y = 532 },
	fackel11 = { X = 311, Y = 529 },
	fackel12 = { X = 307, Y = 525 },
	fackel13 = { X = 320, Y = 520 },
	fackel14 = { X = 316, Y = 516 },
	fackel15 = { X = 325, Y = 509 },
	fackel16 = { X = 320, Y = 509 },
	fackel17 = { X = 323, Y = 529 },
	fackel18 = { X = 326, Y = 526 },
	fackel19 = { X = 329, Y = 536 },
	fackel20 = { X = 332, Y = 532 },
	fackel21 = { X = 340, Y = 540 },
	fackel22 = { X = 340, Y = 536 },
	fackel23 = { X = 347, Y = 541 },
	fackel24 = { X = 347, Y = 535 },
	fackel25 = { X = 358, Y = 544 },
	fackel26 = { X = 370, Y = 544 },
	fackel27 = { X = 370, Y = 532 },
	fackel28 = { X = 358, Y = 532 },
}   



REM = [[
Lagerfeuer
{
	test = { X = 120, Y = 150 },
}   
]]